#include <iostream>
#include <string>
#include <sstream>
#include <vector>
using namespace std;

string Problem1(){
    int n;
    cin>>n;
    int a[n];
    for(int &x : a) cin>>x;
    int indx = a[0];
    string ans;
    for(int i = indx;i<n;i++) ans+=to_string(a[i]);
    for(int i =0;i<indx;i++) ans+=to_string(a[i]);
    return ans;
}

void Problem2(){
    string source;
    getline(cin,source);
    stringstream stream(source);
    vector<string>extr;
    string tmp;
    int longest = 0;
    while(stream>>tmp) {
        extr.push_back(tmp);
        longest = max(longest,(int)tmp.length());
    }
    for(int i =0;i<longest+2;i++) cout<<'*';
    cout<<'\n';
    for(int i =0;i<extr.size();i++){
        string s = extr[i];
        cout<<'*';
        int c =0;
        for(c = 0;c<s.length();c++) cout<<s[c];
        for(int j = c+1;j<longest+1;j++) cout<<' ';
        cout<<"*\n";
    }
    for(int i =0;i<longest+2;i++) cout<<'*';

}


int main(){
 Problem1();
 cout<<"\n\n";
 Problem2();
 return 0;
}